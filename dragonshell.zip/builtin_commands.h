#pragma once

void runBuiltInCommand(std::vector<std::string> arguments, std::string redirectFile = "");
void exitShell();